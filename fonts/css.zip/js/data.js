const initialOverlayData = [
  {
    image: "../../images/Hero/Hero_8.png",
    text: "orem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Labore orem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Laboreorem ipsum dolor sit amet consectetur adipisicing elit.Impedit vel expedita a modi, officia est cumque. Labore",
  },
  {
    image: "../../images/Hero/Hero_7.png",
    text: "reeeeerr",
  },
  {
    image: "../../images/Hero/Hero_3.png",
    text: "rjjjjjjjr",
  },
  {
    image: "../../images/Hero/Hero_1.png",
    text: "vvvvvvvr",
  },
  {
    image: "../../images/Hero/Hero_2.png",
    text: "rbbbbbbbbbjr",
  },
  {
    image: "../../images/Hero/Hero_6.png",
    text: "rbbbbbbbbbjr",
  },
  {
    //ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ
    image: "../../images/Hero/Hero_5.png",
    text: "пользовательское",
  },
  {
    //ПОЛИТИКА КОНФИДЕНЦИАЛЬНОСТИ
    image: "../../images/Hero/Hero_5.png",
    text: "политика",
  },
  {
    image: "../../images/Hero/Hero_4.png",
    text: "rjjooooooojr",
  },
];

export { initialOverlayData };
